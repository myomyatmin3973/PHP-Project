<?php
error_reporting(1);
session_start();
$i=$_REQUEST['img'];
$_SESSION['sid']=$_POST['id'];
include("connection.php");
$i=$_REQUEST['img'];
if($_POST['ord'])
{ 
$prodno=$_POST['prodno'];
$price=$_POST['price'];
$name=$_POST['nam'];
$phone=$_POST['pho'];
$add=$_POST['add'];
$ordno=ord.rand(100,500);
if(mysql_query("insert into orders(productno,price,name,phone,address,order_no) values('$prodno','$price','$name','$phone','$add','$ordno')"))
{
//echo "<script>location.href='ordersent.php?prod'</script>";
header("location:ordersent.php?order_no=$ordno");  }
else {$error= "user already exists";}}

?>


    	
		  <center>
            <h3>Order form</h3>
        <?php
			include("connection.php");
			$sel=mysql_query("select * from item  where img='$i' ");
			$mat=mysql_fetch_array($sel);
			
			
			?>
            <form  method="post">
			<table align="center">
			<tr>
			     <td>Foodname </td>
			     <td><span><input type="text" name="prodno" id="prodno" value="<?php echo $mat['prod_no'];?>" class="input_field"/></span></td>
			</tr>
			
			 <tr>
                        <td height="20px"></td>
                </tr>        
			
			<tr>
			     <td>Price:</td>
			     <td><input type="text" name="price" id="price" value="<?php echo $mat['price'];?>" class="input_field"/></td>
			</tr>
			
			 <tr>
                        <td height="20px"></td>
                </tr>        
			
			<tr>

                 <td>Name: </td>
                 <td><input type="text" name="nam" id="nam" class="input_field" /></td>
			</tr>
			
			 <tr>
                        <td height="20px"></td>
             </tr>        
			
			<tr>
				<td>Phone: </td>
                <td><input type="text" name="pho" id="php" class="input_field" /></td>
			</tr>
			
			 <tr>
                        <td height="20px"></td>
              </tr>        
			
			<tr>
				 <td>Address:</td>
                 <td><textarea id="add" name="add" rows="0" cols="0" class="required"></textarea></td>
			</tr>
			
			 <tr>
                        <td height="20px"></td>
             </tr>   
			
			<td  colspan="2" align="center">
                    <input type="submit" name="ord" id="ord" value="sent order" class="submit_button" />
				 <input type="submit" name="Cancel" value="Cancel" class="submit_button" /><a href="index.php">
                    
              </td>
            </form>
			</table>
        
        </div>
   

    