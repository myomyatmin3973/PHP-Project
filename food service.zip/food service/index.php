<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<!--
Victory HTML CSS Template
https://templatemo.com/tm-507-victory
-->
        <title>Foodbear Shop and Delivery Service! Home page</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="css/fontAwesome.css">
        <link rel="stylesheet" href="css/hero-slider.css">
        <link rel="stylesheet" href="css/owl-carousel.css">
        <link rel="stylesheet" href="css/templatemo-style.css">

        <link href="https://fonts.googleapis.com/css?family=Spectral:200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">

        <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>

<body>
    <div class="header">
        <div class="container">
            <a href="#" class="navbar-brand scroll-top">Foodbear Shop and Delivery Service!</a>
            <nav class="navbar navbar-inverse" role="navigation">
                <div class="navbar-header">
                    <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <!--/.navbar-header-->
                <div id="main-nav" class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="menu.php">Our Menus</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                        <li><a href="register.php">Registration</a></li>
                      

                    </ul>
                </div>
                <!--/.navbar-collapse-->
            </nav>
            <!--/.navbar-->
        </div>
        <!--/.container-->
    </div>
    <!--/.header-->


    <section class="banner">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <h3><b>Welcome from Foodbear  Delivery Online Website</b>.</h3>
                    <h5>Food!</h5>
                    <p>Food is any substance consumed by an organism for nutritional support. Food is usually of plant, animal, or fungal origin, and contains essential nutrients, such as carbohydrates, fats, proteins, vitamins, or minerals.</p>
                    <div class="primary-button">
                        <a href="login.php">Order Right Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="cook-delecious">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-md-offset-1">
                    <div class="first-image">
                        <img src="img/food6.png" alt="">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="cook-content">
                        <h2>Hotline Phone</h2>
                        <div class="contact-content">
                            <span>You can call us on:</span>
                            <h6>+ 1234 567 8910</h6>
                        </div>
                        <span>or</span><br>
                        
                            <a href="login.php">Order Now!</a>
                        
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="second-image">
                        <img src="img/food7.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="services">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="service-item">
                        <a href="menu.html">
                        <img src="img/food2.png" alt="">
                        <h4>Myanmar Food</h4>
                        </a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="service-item">
                        <a href="menu.html">
                        <img src="img/food3.png" alt="">
                        <h4>Korea Food</h4>
                        </a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="service-item">
                        <a href="menu.html">
                        <img src="img/food4.png" alt="">
                        <h4>Thai Food</h4>
                        </a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="service-item">
                        <a href="menu.html">
                        <img src="img/food5.png" alt="">
                        <h4>Japan Food</h4>
                        </a>

                    </div>
                </div>
            </div>
        </div>
    </section>



    



    <section class="get-app">
        <div class="container">
            <div class="row">
                <div class="heading">
                    <h2>Thank You for Order My Food Delivery Service</h2>
                </div>
                <div class="primary-white-button">
                    <a href="#"></a>
                </div>
            </div>
        </div>
    </section>



    <section class="featured-food">
        <div class="container">
            <div class="row">
                <div class="heading">
                    <h2>Available Sample food in this shop</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-2">
                    <div class="food-item">
                        <h2>Myanmar Traditional Food</h2>
                        <img src="img/food9.png" alt="" class="mohinga">
                        <div class="price">2000ks</div>
                        <div class="text-content">
                            <h4>Mohinga</h4>
                            <p>Mohinga is a rice noodle and fish soup from Myanmar and an essential part of Burmese cuisine, considered by many to be the national dish of Myanmar.Mohinga is traditionally eaten for breakfast, but today is eaten at any time of day.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-2">
                    <div class="food-item">
                        <h2>Korea Traditional Food</h2>
                        <img src="img/food10.png" alt="">
                        <div class="price">5500ks</div>
                        <div class="text-content">
                            <h4>Bibimbap</h4>
                            <p>Bibimbap is korean lunch-in-a-bowl mixes together a simple salad of rice, mixed vegetables, rice, beef and egg, with sesame oil and a dollop of chili paste for seasoning.
                            Most of the korea really like this traditional food.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-2">
                    <div class="food-item">
                        <h2>Thai Traditional Food</h2>
                        <img src="img/food11.png" alt="">
                        <div class="price">7000ks</div>
                        <div class="text-content">
                            <h4>Pad Thai</h4>
                            <p>One of the most known foods of Thailand and is also widely accepted by Western palates. A traditional Pad Thai recipe includes rice noodles stir-fried with eggs and tofu, seasoned with tamarind juice, fish sauce, dried shrimp, garlic, onion, pepper, and palm sugar. It is usually served with bean sprouts, lemon slices, and roasted peanuts. Many variations add fresh shrimp, chicken, or pork.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-2">
                    <div class="food-item">
                        <h2>Japan Traditional Food</h2>
                        <img src="img/food12.png" alt="">
                        <div class="price">8000ks</div>
                        <div class="text-content">
                            <h4>Sushi</h4>
                            <p>Sushi is a Japanese dish of prepared vinegared rice, usually with some sugar and salt, accompanied by a variety of ingredients, such as seafood, often raw, and vegetables. Styles of sushi and its presentation vary widely, but the one key ingredient is "sushi rice," also referred to as shari, or sumeshi.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="our-blog">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="heading">
                        <h2>Our Service!</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="blog-post">
                        <img src="img/food13.png" alt="">
                        
                        <div class="right-content">
                            <h4>Food Needs To Be  Delivered Correctly!</h4>
                            <span>Branding / Admin</span>
                            <p>This shaking mixes the food during the delivery route is an essential aspect of your restaurant’s delivery service. There are several significant factors to consider in this regard,...</p>
                            <div class="text-button">
                                <a href="#">Continue Reading</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="blog-post">
                        <img src="img/food14.png" alt="">
                        <div class="right-content">
                            <h4>On-Time Delivery System in here!</h4>
                            <span>Branding / Admin</span>
                            <p>In terms of service quality, response time is one of the most important KPIs, which depends on the proximity of drivers to the restaurant and their optimal distribution and customer are ...</p>
                            <div class="text-button">
                                <a href="#">Continue Reading</a>
                            </div>
                        </div>
                    </div>
                </div>
                
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



    

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <p>Copyright &copy; 2023 Foodbear shop</p>
                </div>
                <div class="col-md-4">
                    <ul class="social-icons">
                        <li><a rel="nofollow" href="https://www.facebook.com/profile.php?id=100034977468179"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-rss"></i></a></li>
                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <p>Design: Foodbear IT company</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.min.js"><\/script>')</script>

    <script src="js/vendor/bootstrap.min.js"></script>

    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

    <script type="text/javascript">
    $(document).ready(function() {
        // navigation click actions 
        $('.scroll-link').on('click', function(event){
            event.preventDefault();
            var sectionID = $(this).attr("data-id");
            scrollToID('#' + sectionID, 750);
        });
        // scroll to top action
        $('.scroll-top').on('click', function(event) {
            event.preventDefault();
            $('html, body').animate({scrollTop:0}, 'slow');         
        });
        // mobile nav toggle
        $('#nav-toggle').on('click', function (event) {
            event.preventDefault();
            $('#main-nav').toggleClass("open");
        });
    });
    // scroll function
    function scrollToID(id, speed){
        var offSet = 0;
        var targetOffset = $(id).offset().top - offSet;
        var mainNav = $('#main-nav');
        $('html,body').animate({scrollTop:targetOffset}, speed);
        if (mainNav.hasClass("open")) {
            mainNav.css("height", "1px").removeClass("in").addClass("collapse");
            mainNav.removeClass("open");
        }
    }
    if (typeof console === "undefined") {
        console = {
            log: function() { }
        };
    }
    </script>
</body>
</html>