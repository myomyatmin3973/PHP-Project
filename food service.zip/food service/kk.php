<section class="page-heading">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Our Menus</h1>
                    <p>In a restaurant, the menu is a list of food and beverages offered to customers and the prices.Menus are also often a feature of very formal meals other than in restaurants, for example at weddings.</p>
                </div>
            </div>
        </div>
    </section>



    <section class="breakfast-menu">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="breakfast-menu-content">
                        <div class="row">
                            <div class="col-md-5">
                                <div class="left-image">
                                    <img src="img/food18.jpg" alt="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h2>Myanmar  Food Menu</h2><br>
                                <div id="owl-breakfast" class="owl-carousel owl-theme">
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food17.jpg" alt="">
                                            <div class="price">2000ks</div>
                                            <div class="text-content">
                                                <h4> Nan Gyi Thote</h4>
                                                <p>Nan gyi thoke is an a thoke salad dish in Burmese cuisine, made with thick round. ...</p>
                                                <br><a href='login.php?'><b>Buy</b></a>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food19.jpg" alt="">
                                            <div class="price">2500ks</div>
                                            <div class="text-content">
                                                <h4>Coconut noodle</h4>
                                                <p>Coconut noodles are made from young fresh coconut water and come moist but not in extra water....</p>
                                                <a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food20.jpg" alt="">
                                            <div class="price">2500ks</div>
                                            <div class="text-content">
                                                <h4>Hsi htamin</h4>
                                                <p>Hsi htamin is a traditional Burmese snack or mont, popularly served as a breakfast dish...</p>
                                                <br><a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food21.jpg" alt="">
                                            <div class="price">2000ks</div>
                                            <div class="text-content">
                                                <h4>Shan noodle</h4>
                                                <p>Shan noodle is an easy-to-make Burmese recipe where chicken or pork cooked in tomatoes...</p>
                                                <a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food22.jpg" alt="">
                                            <div class="price">1500ks</div>
                                            <div class="text-content">
                                                <h4>Tea leaf salad (La Phat Thote)</h4>
                                                <p>Lahpet Thoke also known as Myanmar (Burmese) tea leaf salad, is one of the most popular dishes...</p>
                                                <br><a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food23.jpg" alt="">
                                            <div class="price">8000ks</div>
                                            <div class="text-content">
                                                <h4>Burmese Tempura(A Kyaw Sone)</h4>
                                                <p>Burmese Tempura(A Kyaw Sone) It is a kind of favorite street food which is usually served... </p>
                                                <a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section class="lunch-menu">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="lunch-menu-content">
                        <div class="row">
                            <div class="col-md-6">
                                <h2>Korea Food Menu</h2>
                                <div id="owl-lunch" class="owl-carousel owl-theme">
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food24.jpg" alt="">
                                            <div class="price">10000ks</div>
                                            <div class="text-content">
                                                <h4>Bulgogi</h4>
                                                <p>Bulgogi, literally "fire meat", is a gui made of thin, marinated slices of meat...</p>
                                                <a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food27.jpg" alt="">
                                            <div class="price">9000ks</div>
                                            <div class="text-content">
                                                <h4>Samgye-tang</h4>
                                                <p>Samgye-tang or ginseng chicken soup, meaning ginseng - chicken - soup in Korean...</p>
                                                <br><a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food26.jpg" alt="">
                                            <div class="price">15000ks</div>
                                            <div class="text-content">
                                                <h4>Bossam</h4>
                                                <p>Bossam (보쌈) is a boiled pork dish. The meat is boiled in a flavorful brine until tender ...</p>
                                                <br><a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food28.jpg" alt="">
                                            <div class="price">4000ks</div>
                                            <div class="text-content">
                                                <h4>Kimchi jjigae</h4>
                                                <p>Kimchi jjigae or kimchi stew is a great use for leftover or ripe kimchi.Aside from baechu ...</p>
                                                <a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food29.jpg" alt="">
                                            <div class="price">5000ks</div>
                                            <div class="text-content">
                                                <h4>Japchae</h4>
                                                <p>Japchae is a popular stir-fried noodle dish and is one of the most versatile traditional Korean foods...</p>
                                                <br><a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food30.jpg" alt="">
                                            <div class="price">5000ks</div>
                                            <div class="text-content">
                                                <h4>Kimbap</h4>
                                                <p>Kimbap has to be one of the most all-rounded traditional Korean foods.This simple rice roll filled with ...</p>
                                                <a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="left-image">
                                    <img src="img/food25.jpg" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    <section class="dinner-menu">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="dinner-menu-content">
                        <div class="row">
                            <div class="col-md-5">
                                <div class="left-image">
                                    <img src="img/food31.jpg" alt=""><br>
                                    <img src="img/food40.jpg" alt="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h2>Thai and Japan Food Menu</h2>
                                <div id="owl-dinner" class="owl-carousel owl-theme">
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food32.jpg" alt="">
                                            <div class="price">5000ks</div>
                                            <div class="text-content">
                                                <h4>Tom Yum Goong</h4>
                                                <p>Tom Yum Goong, a type of spicy shrimp soup, is one of the most popular soups in Thailand, which can be found ...</p>
                                            <a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food33.jpg" alt="">
                                            <div class="price">6000ks</div>
                                            <div class="text-content">
                                                <h4>Thai Beef Salad</h4>
                                                <p>Thai Beef Salad, also called Yum Nuea, is one of the typical dishes that you can find in most of....</p>
                                                <br><a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food34.jpg" alt="">
                                            <div class="price">4500ks</div>
                                            <div class="text-content">
                                                <h4>Phat Kaphrao </h4>
                                                <p>Phat Kaphrao, stir-fried meat with basil and chilli, is great dish for people who are in a hurry to ...</p>
                                                <br><br><a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food35.jpg" alt="">
                                            <div class="price">3000ks</div>
                                            <div class="text-content">
                                                <h4>Mango Sticky Rice</h4>
                                                <p>Mango Sticky Rice is something you should try if you want get deeper insights of the roots of Thai traditional foods....</p>
                                                <br><a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food36.jpg" alt="">
                                            <div class="price">4000ks</div>
                                            <div class="text-content">
                                                <h4>Okonomiyaki</h4>
                                                <p>Okonomiyaki is a Japanese Teppanyaki, savoury pancake dish consisting of wheat flour batter and other ingredients....</p>
                                                <a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food37.jpg" alt="">
                                            <div class="price">5000ks</div>
                                            <div class="text-content">
                                                <h4>Miso Soup</h4>
                                                <p>Miso soup is a traditional Japanese soup consisting of a dashi stock into which softened miso paste....</p>
                                                <br><a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food38.jpg" alt="">
                                            <div class="price">9000ks</div>
                                            <div class="text-content">
                                                <h4>Yakitori</h4>
                                                <p>Yakitori is a Japanese type of skewered chicken. Its preparation involves skewering the meat....</p>
                                                <br><br><a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item col-md-12">
                                        <div class="food-item">
                                            <img src="img/food39.jpg" alt="">
                                            <div class="price">5000ks</div>
                                            <div class="text-content">
                                                <h4>Unagi</h4>
                                                <p>Unagi is the Japanese word for freshwater eel, particularly the Japanese eel, Anguilla japonica. Unagi is a common ingredient in Japanese...</p>
                                                <a href='login.php?img=$i'><b>Buy</b></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>